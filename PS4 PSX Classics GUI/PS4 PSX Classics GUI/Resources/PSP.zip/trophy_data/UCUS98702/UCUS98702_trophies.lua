-- Lua 5.3
-- Title:   Parappa The Rapper PSP - UCUS-98702 (USA)
-- Author:  Adam McInnis, Ernesto Corvi

-- Changelog:
-- version 1.1 - Fixed issue where trophy would trigger if exited the middle of a stage and was Good or Cool.
-- version 1.2 - Fixed issue where it could trigger RIGHT_ON_QUEUE if exit in the middle of a stage.
-- version 1.3 - Removed trophies: JOE_CHINS_GOT_SUNNYS_HEART and REPLAY_REPLAY.
-- version 1.4 - Fixed issue when finishing in Cool not triggering trophy.
-- version 1.5 - Updated trophy "Remix Edition" so that all 6 secrets are required to complete trophy.
-- version 1.6 - In EU & JP builds, correct trophy list for COMEBACK_KING & RIGHT_ON_QUEUE.
-- version 1.7 - Fixed logic bug for Easy mode.
-- version 1.8 - Fixed other logic bug for Easy mode.

apiRequest(1.0)	-- request version 1.0 API. Calling apiRequest() is mandatory.

local emuObj	= getEmuObject() -- emulator
local axObj		= getAXObject() -- allegrex
local trophyObj	= getTrophyObject()
local gpr		= require( "ax-gpr-alias" ) -- you can access Allegrex GPR by alias (gpr.a0 / gpr["a0"])

local 	HIP_HOP_HERO					=  0 -- You've gotta believe!
local 	PRACTICE_MAKES_PERFECT			=  1 -- PaRappa and Katy Kat feelin’ the flow.                                    Complete all four stages in the Practice level.
local 	LESSON_LEARNED					=  2 -- Out chop the Chop Chop Master for the first time.                         Clear stage 1 with any rating on Normal difficulty.
local 	MASTER_MASTER_ONION				=  3 -- Be a Good student for your Master.                                        Clear stage 1 on Normal difficulty with a Good rating.
local 	KICK_TO_THE_LIMIT				=  4 -- Blow the walls off with a seriously Cool rap. Are you the man now?        Clear stage 1 on Normal difficulty with a Cool rating.
local 	LEARNERS_PERMIT					=  5 -- Time to show show Instructor Mooselini what groove you know know.         Clear stage 2 with any rating on Normal difficulty.
local 	STEP_ON_THE_GAS					=  6 -- Good work! Come on, let's jam!                                            Clear stage 2 on Normal difficulty with a Good rating.
local 	LICENSE_TO_DRIVE				=  7 -- Cool! Now step on the gas!                                                Clear stage 2 on Normal difficulty with a Cool rating.
local 	GOT_THE_GOT_THE_FUNKY_FLOW		=  8 -- Show Prince Fleaswallow that you can rap real slow.                       Clear stage 3 with any rating on Normal difficulty.
local 	BE_NICE_AND_FRIENDLY			=  9 -- Be a Good employee down at the flea market.                               Clear stage 3 on Normal difficulty with a Good rating.
local 	ALL_YOU_EVER_NEED				= 10 -- It's Cool to know how to close a sale.                                    Clear stage 3 on Normal difficulty with a Cool rating.
local 	COOKING_ON_THE_CHEAP_CHEAP		= 11 -- Master cooking with Cheap Cheap the Cooking Chicken.                      Clear stage 4 with any rating on Normal difficulty.
local 	BEEN_DOIN_THIS_FOR_YEARS		= 12 -- It's a weird cake, but it's a Good cake.                                  Clear stage 4 on Normal difficulty with a Good rating.
local 	A_CAKE_YOUVE_NEVER_SEEN_BEFORE	= 13 -- Your style is rich, dope, phat, and Cool!                                 Clear stage 4 on Normal difficulty with a Cool rating.
local 	I_GOTTA_GO_GO_GO				= 14 -- Pass Full Tank with class to show Sunny that you are still manly.         Clear stage 5 with any rating on Normal difficulty.
local 	CRACK_BREAK_FIX_THE_DOOR		= 15 -- Phew! Good thing you made it.                                             Clear stage 5 on Normal difficulty with a Good rating.
local 	A_CHICKEN_FROM_THE_KITCHEN		= 16 -- I ain't kidding, though nothing is written.                               Clear stage 5 on Normal difficulty with a Cool rating.
local 	HERE_COMES_YOUR_HERO			= 17 -- Show M.C. King Kong Mushi that you gotta believe!                         Clear stage 6 with any rating on Normal difficulty.
local 	PUMP_UP_THE_NIGHT				= 18 -- Now you're running up and down the street with the juice!                 Clear stage 6 on Normal difficulty with a Good rating.
local 	IT_AINT_A_PROBLEM_FOR_THE_MAN	= 19 -- Achieve your destiny as the coolest hero!                                 Clear stage 6 on Normal difficulty with a Cool rating.
local 	FREESTYLE_HERO					= 20 -- Freestyle your way into a Cool rating for all songs.                      Clear all stages with a Cool rating.
local 	FLOWER_POWER					= 21 -- Unlock and play "KC and the Sunny Funny Band."                            This opens up if you clear all stages with a Cool rating.
local 	EASY_IS_FOR_BABIES				= 22 -- Clear all stages on Easy difficulty.                                      Clear all stages with a Good rating.
local 	YOU_GOTTA_DO_WHAT				= 23 -- Clear all stages on Normal difficulty.                                    Clear all stages with a Good or Cool rating.
local 	REMIX_EDITION					= 24 -- Check out the alternate stages!                                           In Normal difficulty, Hold "Up" to reveal the showering onion student (Mado) or onion/chop poster guy (Kamon) in Stage 1 with a Good or Cool rating. In Lesson 3 or 4, hold Up & R1 on "R1" 2nd star (Mado) and Up & X on 4th star (Kamon).
local 	PLEASE_PLEASE_STOP_THE_FLOW		= 25 -- Clear any stage with a rating of Awful.                                
local 	RIGHT_ON_QUEUE					= 26 -- Prove that you know your way around the microphone. Don't miss a beat!    Clear any stage on Normal difficulty without missing a single note (indicated by losing points)
local 	COMEBACK_KING					= 27 -- Turn an Awful performance into a Cool one.                                Reach an Awful rating at any point during a song but finish with a Cool rating.            


local EASY		= 1 -- easy difficulty
local NORMAL	= 0 -- normal difficulty
local COOL		= 0 -- Cool rapState
local GOOD		= 1 -- Good rapState
local BAD		= 2 -- Bad rapState
local AWFUL		= 3 -- Awful rapState
local PLAYING	= 0 -- eventMode playing
local DEMO		= 1 -- eventMode demo
local REPLAY	= 2 -- eventMode replay

local SaveData = emuObj.LoadConfig()
local gameStateRunning = false
local gameNoMissedBeats = true
local eventMode = 0
local badPerformance = false
local altActivated = false
local stageEndReached = false

function initsaves()
	local needsSave = false
	
	if SaveData.t == nil then
		SaveData.t = {}
		needsSave = true
	end
	
	for x = 0, 27 do
		if SaveData.t[x] == nil then
			SaveData.t[x] = 0
			needsSave = true
		end
	end

	if SaveData.cool == nil then
		SaveData.cool = {}
		needsSave = true
	end
	if SaveData.easy == nil then
		SaveData.easy = {}
		needsSave = true
	end
	if SaveData.normal == nil then
		SaveData.normal = {}
		needsSave = true
	end

	if SaveData.ninja == nil then
		SaveData.ninja = {}
		needsSave = true
	end
	
	for x = 1,6 do
		if SaveData.ninja[x] == nil then
			SaveData.ninja[x] = 0
			needsSave = true
		end
	end

	if (needsSave == true) then
		emuObj.SaveConfig(SaveData)
	end
	
end
initsaves()

function trophyCleanup()
	if SaveData.t[28] ~= nil then
		SaveData.t[26] = SaveData.t[28]		-- Removed JOE_CHINS_GOT_SUNNYS_HEART
		SaveData.t[27] = SaveData.t[29]		-- Removed REPLAY_REPLAY
		SaveData.t[28] = nil
		SaveData.t[29] = nil
		emuObj.SaveConfig(SaveData)
	end
end
trophyCleanup()

function unlockTrophy(trophy_id)
	if SaveData.t[trophy_id] ~= 1 then
		SaveData.t[trophy_id] = 1
		trophyObj.Unlock(trophy_id)
		emuObj.SaveConfig(SaveData)
		SaveDataDirty = false
	end
end

--- GAME FUNCTIONS ---

function checkCool()
	emuObj.SaveConfig(SaveData)
	local complete = true

	for stage = 1, 6 do
		if SaveData.cool[stage] == nil then
			complete = false
		end
	end
	
	if complete == true then
		unlockTrophy(FREESTYLE_HERO)	-- Clear all stages with a Cool rating.
	end
	return
end

function checkNormal()
	emuObj.SaveConfig(SaveData)
	local complete = true

	for stage = 1, 6 do
		if SaveData.normal[stage] == nil then
			complete = false
		end
	end
	
	if complete == true then
		unlockTrophy(YOU_GOTTA_DO_WHAT)	-- Clear all stages on Normal difficulty.
	end
	return
end

function checkEasy()
	emuObj.SaveConfig(SaveData)
	local complete = true

	for stage = 1, 3 do
		if SaveData.easy[stage] == nil then
			complete = false
		end
	end
	
	if complete == true then
		unlockTrophy(EASY_IS_FOR_BABIES)	-- Clear all stages on Easy difficulty.
	end
	return
end

function checkNinja()
	ninjaCheck = true
	
	for i = 1, 6 do
		if SaveData.ninja[i] ~= 1 then
			ninjaCheck = false
		end
	end

	if ninjaCheck == true then
		unlockTrophy(REMIX_EDITION) -- In Normal difficulty, Hold "Up" to reveal the "secrets". 6 secrets total.
	end
	
	-- 3 in stage 1 - I Need to Become A Hero
	--		UP + any wrong button (ceiling) frame 37 (pass 31)
	--		UP + R1 - Lesson 3 or 4 on 2nd star (Mado - shower)
	--		UP + X  - Lesson 3 or 4 on 4th star (Kamon - chop/onion)
	-- 2 in stage 2 - You Guys Sit in The Back
	--		UP + R1 frame 24 (pass 21)
	--		UP + L1 frame 20 (pass 17)
	-- 1 in stage 6 - I Gotta Believe!!
	--		UP + button frame 47 (pass 30)
end

--- MAIN ---

local H1 = function() -- ParaSceneRun
	local pc = axObj.GetPC()
	local status = axObj.GetGpr(gpr.v0)
	local difficulty = axObj.ReadMem8(0x8a33a9e)	-- 0 = normal, 1 = easy (S_SelectSceneInit: 89214 [233A9E + 8800000 = 8a33a9e])
	local rapState = axObj.ReadMem16(0x8a88aee)		-- 0 = cool, 1 = good, 2 = bad, 3 = awful (ParaSceneRun: 8D750 [288aa0 + 4e = 288aee) + 8800000 = 8a88aee])

	if status == 1 then
		stageEndReached = true	-- Finished stage in Cool mode, but stageEndReached doesn't get activated. Update flag.
	end

	if eventMode == PLAYING and stageEndReached == true then
		if difficulty == NORMAL and gameNoMissedBeats == true and rapState <= GOOD then
			unlockTrophy(RIGHT_ON_QUEUE)				-- Clear any stage on Normal difficulty without missing a single note (indicated by losing points)
		elseif rapState == AWFUL then
			unlockTrophy(PLEASE_PLEASE_STOP_THE_FLOW)	-- Clear any stage with a rating of Awful.
		end

print(string.format("**** rapState: %d, difficulty: %d", rapState, difficulty))
		if difficulty == EASY then
			if rapState <= GOOD then								-- Easy mode (good or cool rating required)
				if pc == 0x888f33c then
					SaveData.easy[1] = true
					checkEasy()
				elseif pc == 0x8891658 then
					SaveData.easy[2] = true
					checkEasy()
				elseif pc == 0x88b22a4 then
					SaveData.easy[3] = true
					checkEasy()
				end
			end
		else -- Normal with good & cool difficulty --
			if pc == 0x888f33c then									-- Stage 1
				if rapState == GOOD then
					unlockTrophy(MASTER_MASTER_ONION)				-- Clear stage 1 on Normal difficulty with a Good rating.
					SaveData.normal[1] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(KICK_TO_THE_LIMIT)					-- Clear stage 1 on Normal difficulty with a Cool rating.
					SaveData.cool[1] = true
					checkCool()
				end
				unlockTrophy(LESSON_LEARNED)						-- Clear stage 1 with any rating on Normal difficulty.
			elseif pc == 0x8891658 then								-- Stage 2
				if rapState == GOOD then
					unlockTrophy(STEP_ON_THE_GAS)					-- Clear stage 2 on Normal difficulty with a Good rating.
					SaveData.normal[2] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(LICENSE_TO_DRIVE)					-- Clear stage 2 on Normal difficulty with a Cool rating.
					SaveData.cool[2] = true
					checkCool()
				end		
				unlockTrophy(LEARNERS_PERMIT)						-- Clear stage 2 with any rating on Normal difficulty.
			elseif pc == 0x88b22a4 then								-- Stage 3
				if rapState == GOOD then
					unlockTrophy(BE_NICE_AND_FRIENDLY)				-- Clear stage 3 on Normal difficulty with a Good rating.
					SaveData.normal[3] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(ALL_YOU_EVER_NEED)					-- Clear stage 3 on Normal difficulty with a Cool rating.
					SaveData.cool[3] = true
					checkCool()
				end		
				unlockTrophy(GOT_THE_GOT_THE_FUNKY_FLOW)			-- Clear stage 3 with any rating on Normal difficulty.
			elseif pc == 0x88b45c0 then								-- Stage 4
				if rapState == GOOD then
					unlockTrophy(BEEN_DOIN_THIS_FOR_YEARS)			-- Clear stage 4 on Normal difficulty with a Good rating.
					SaveData.normal[4] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(A_CAKE_YOUVE_NEVER_SEEN_BEFORE)	-- Clear stage 4 on Normal difficulty with a Cool rating.
					SaveData.cool[4] = true
					checkCool()
				end		
				unlockTrophy(COOKING_ON_THE_CHEAP_CHEAP)			-- Clear stage 4 with any rating on Normal difficulty.
			elseif pc == 0x88b68f4 then								-- Stage 5
				if rapState == GOOD then
					unlockTrophy(CRACK_BREAK_FIX_THE_DOOR)			-- Clear stage 5 on Normal difficulty with a Good rating.
					SaveData.normal[5] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(A_CHICKEN_FROM_THE_KITCHEN)		-- Clear stage 5 on Normal difficulty with a Cool rating.
					SaveData.cool[5] = true
					checkCool()
				end		
				unlockTrophy(I_GOTTA_GO_GO_GO)						-- Clear stage 5 with any rating on Normal difficulty.
			elseif pc == 0x88b8da0 then								-- Stage 6
				if rapState == GOOD then
					unlockTrophy(PUMP_UP_THE_NIGHT)					-- Clear stage 6 on Normal difficulty with a Good rating.
					SaveData.normal[6] = true
					checkNormal()
				elseif rapState == COOL then
					unlockTrophy(IT_AINT_A_PROBLEM_FOR_THE_MAN)		-- Clear stage 6 on Normal difficulty with a Cool rating.
					SaveData.cool[6] = true
					checkCool()
				end		
				unlockTrophy(HERE_COMES_YOUR_HERO)					-- Clear stage 6 with any rating on Normal difficulty.
			end
		end
		if altActivated == true then
			checkNinja()											-- Check to see if all "secrets" completed.
		end

		if badPerformance == true and rapState == COOL then
			unlockTrophy(COMEBACK_KING)		-- Reach an Awful rating at any point during a song but finish with a Cool rating.
		end
	end
	
	gameStateRunning = false
end

local H2 = function() -- ParaEventRecorderInit (note: we use this to determine the start of a Stage)
	eventMode = axObj.ReadMem16(0x8a33a90)	-- 0 = playing, 1 = demo, 2 = replay (ParaAppInit: 78C94 [233a90 + 88000000 = 8a33a90])

	if eventMode == PLAYING then
		gameStateRunning = true
		gameNoMissedBeats = true
	else
		gameStateRunning = false
		gameNoMissedBeats = false
	end
	badPerformance = false
	altActivated = false
	stageEndReached = false
end

local H3 = function() -- ParaPracticeRun
	local complete = axObj.GetGpr(gpr.v0)

	if complete == 1 then
		unlockTrophy(PRACTICE_MAKES_PERFECT)	-- Complete all four stages in the Practice level.
	end
end

local H5 = function() -- ParaActionEvaluateTerm
	local adj = axObj.GetGpr(gpr.a0)

	if (adj & 0x80000000) ~= 0 then
		gameNoMissedBeats = false
	end
end

local H6 = function() -- ParaEventDynGetNext
	stageEndReached = true
end

local H7 = function() -- ParaSceneRunS9
	unlockTrophy(FLOWER_POWER) --Unlock and play "KC and the Sunny Funny Band." - This opens up if you clear all stages with a Cool rating.
end

local H8 = function() -- ParaEventSpecialHandler_0
	local ninja = axObj.ReadMem16(axObj.GetGpr(gpr.a0) + 0x7c) -- 2) ceiling ninja (T?), 3) shower guy (Mado), 4) onion (chop/Kamon?)

	if ninja == 2 then
		if SaveData.ninja[1] == 0 then
			SaveData.ninja[1] = 1		-- UP + any wrong button (ceiling) frame 37 (pass 31)
			emuObj.SaveConfig(SaveData)
			altActivated = true
		end
	elseif ninja == 3 then
		if SaveData.ninja[2] == 0 then
			SaveData.ninja[2] = 1		-- UP + R1 - Lesson 3 or 4 on 2nd star (Mado - shower)
			emuObj.SaveConfig(SaveData)
			altActivated = true
		end
	elseif ninja == 4 then
		if SaveData.ninja[3] == 0 then
			SaveData.ninja[3] = 1		-- UP + X  - Lesson 3 or 4 on 4th star (Kamon - chop/onion)
			emuObj.SaveConfig(SaveData)
			altActivated = true
		end
	end
end

local H9 = function() -- ParaEventSpecialHandler_1 - Drivers Ed - UP + R1 frame 24 (pass 21)
	if SaveData.ninja[4] == 0 then
		SaveData.ninja[4] = 1
		emuObj.SaveConfig(SaveData)
		altActivated = true
	end
end

local H10 = function() -- ParaEventSpecialHandler_1 - Drivers Ed - UP + L1 frame 20 (pass 17)
	if SaveData.ninja[5] == 0 then
		SaveData.ninja[5] = 1
		emuObj.SaveConfig(SaveData)
		altActivated = true
	end
end

local H11 = function() -- ParaEventSpecialHandler_5	- Finale - UP + button frame 47 (pass 30)
	if SaveData.ninja[6] == 0 then
		SaveData.ninja[6] = 1
		emuObj.SaveConfig(SaveData)
		altActivated = true
	end
end

--- HOOKS ---
local hook1 = axObj.AddHook(0x888f33c, 0x24030001, H1)	-- ParaSceneRun_0
local hook2 = axObj.AddHook(0x8891658, 0x24030001, H1)	-- ParaSceneRun_1
local hook3 = axObj.AddHook(0x88b22a4, 0x24030001, H1)	-- ParaSceneRun_2
local hook4 = axObj.AddHook(0x88b45c0, 0x24030001, H1)	-- ParaSceneRun_3
local hook5 = axObj.AddHook(0x88b68f4, 0x24030001, H1)	-- ParaSceneRun_4
local hook6 = axObj.AddHook(0x88b8da0, 0x24030001, H1)	-- ParaSceneRun_5
local hook7 = axObj.AddHook(0x8887690, 0x3c0308c0, H2)	-- ParaEventRecorderInit
local hook8 = axObj.AddHook(0x888b668, 0x24030001, H3)	-- ParaPracticeRun
local hook9 = axObj.AddHook(0x88786a0, 0x00641821, H5)	-- ParaActionEvaluateTerm
local hook10 = axObj.AddHook(0x8886e44, 0x2c410002, H6) -- ParaEventDynGetNext
local hook11 = axObj.AddHook(0x88bb48c, 0x27bdfff0, H7) -- ParaSceneRunS9
local hook12 = axObj.AddHook(0x88958B4, 0x8c850000, H8)	-- ParaEventSpecialHandler_0
local hook13 = axObj.AddHook(0x8898038, 0xa0800180, H9)	-- ParaEventSpecialHandler_1
local hook14 = axObj.AddHook(0x889807C, 0xa0830180, H10)-- ParaEventSpecialHandler_1
local hook15 = axObj.AddHook(0x88AD5F4, 0xac650000, H11)-- ParaEventSpecialHandler_5


emuObj.AddVsyncHook(function()
	local rapState = axObj.ReadMem16(0x8a88aee)		-- 0 = cool, 1 = good, 2 = bad, 3 = awful

	if rapState == AWFUL then
		badPerformance = true
	end
end)
 