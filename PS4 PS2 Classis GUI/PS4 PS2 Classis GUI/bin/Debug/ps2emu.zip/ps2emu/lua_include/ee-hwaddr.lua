gif_hw  = {}
vif0_hw = {}
vif1_hw = {}

gif_hw.CHCR			= 0x1000A000
gif_hw.MADR			= 0x1000A010
gif_hw.QWC			= 0x1000A020
gif_hw.TADR			= 0x1000A030
gif_hw.ASR0			= 0x1000A040
gif_hw.ASR1			= 0x1000A050
gif_hw.SADR			= 0x1000A080

vif0_hw.CHCR		= 0x10008000
vif0_hw.MADR		= 0x10008010
vif0_hw.QWC			= 0x10008020
vif0_hw.TADR		= 0x10008030
vif0_hw.ASR0		= 0x10008040
vif0_hw.ASR1		= 0x10008050
vif0_hw.SADR		= 0x10008080

vif1_hw.CHCR		= 0x10009000
vif1_hw.MADR		= 0x10009010
vif1_hw.QWC			= 0x10009020
vif1_hw.TADR		= 0x10009030
vif1_hw.ASR0		= 0x10009040
vif1_hw.ASR1		= 0x10009050
vif1_hw.SADR		= 0x10009080
